import { useState, useEffect } from "react";

const REAL_CUSTOMERS = [
  { id:"354233755", custId:"CID119101154", name:"CHAMPA DEVI", village:"Soso", center:"65", mobile:"6205727551", officer:"SF0061105", demand:3610, pending:3610, odRemarks:"", status:"Pending" },
  { id:"355340281", custId:"SSF3350728", name:"BILASO DEVI", village:"Chaingada", center:"447413", mobile:"9229087695", officer:"SF0061105", demand:4247, pending:4247, odRemarks:"", status:"Pending" },
  { id:"355562376", custId:"SSF3058691", name:"PRATIMA DEVI", village:"Lari", center:"414373", mobile:"9304157771", officer:"SF0053924", demand:3690, pending:3690, odRemarks:"", status:"Pending" },
  { id:"355590780", custId:"SSF2934294", name:"RUNIYA DEVI", village:"Jobo", center:"470018", mobile:"6203192324", officer:"SF0059413", demand:2223, pending:2223, odRemarks:"", status:"Pending" },
  { id:"355718322", custId:"SID2125764919", name:"RABIYA KHATOON", village:"Chitarpur", center:"372808", mobile:"8815542477", officer:"SF0053924", demand:4263, pending:4263, odRemarks:"", status:"Pending" },
  { id:"355726629", custId:"SSF3556557", name:"SABITA DEVI", village:"Sevta", center:"171232", mobile:"9065999662", officer:"SF0061105", demand:2791, pending:2791, odRemarks:"", status:"Pending" },
  { id:"355947373", custId:"SSF5831452", name:"ANITA KUMARI", village:"Hesalong", center:"Hesalong C1", mobile:"9693053043", officer:"SF0059413", demand:2240, pending:2239, odRemarks:"", status:"Pending" },
  { id:"356180150", custId:"SSF3324585", name:"BABITA DEVI", village:"Piri", center:"182", mobile:"7061097019", officer:"SF0053924", demand:2830, pending:2830, odRemarks:"", status:"Pending" },
  { id:"356204129", custId:"SID2125220145", name:"BASANTI DEVI", village:"Rajwar Tola", center:"93", mobile:"8292467914", officer:"SF0059413", demand:4270, pending:4270, odRemarks:"", status:"Pending" },
  { id:"356367591", custId:"SSF2726771", name:"SONI KUMARI", village:"Devariya", center:"254", mobile:"9241516709", officer:"SF0059413", demand:2780, pending:2780, odRemarks:"", status:"Pending" },
  { id:"356473075", custId:"SSF2636933", name:"RUBI KHATUN", village:"Gidi", center:"208", mobile:"9229916595", officer:"SF0061105", demand:3470, pending:3470, odRemarks:"", status:"Pending" },
  { id:"356706363", custId:"CID119107468", name:"SHAKILA", village:"Lapanga", center:"392", mobile:"6203037712", officer:"SF0059413", demand:4230, pending:4230, odRemarks:"", status:"Pending" },
  { id:"357071402", custId:"SID951374058943", name:"JAIBUN NISHA", village:"Gola", center:"Gola C1", mobile:"9661490118", officer:"SF0053924", demand:3470, pending:3470, odRemarks:"", status:"Pending" },
  { id:"357264627", custId:"SSF6255524", name:"SAMIRA KHATUN", village:"Kute", center:"659393", mobile:"8092738465", officer:"SF0053924", demand:2240, pending:2240, odRemarks:"", status:"Pending" },
  { id:"357669150", custId:"SSF3242148", name:"GITA DEVI", village:"Bhurkunda", center:"Bhurkunda C3", mobile:"7455890690", officer:"SF0059413", demand:2780, pending:2780, odRemarks:"", status:"Pending" },
  { id:"357669301", custId:"SSF3240422", name:"MEENA DEVI", village:"Bhurkunda", center:"Bhurkunda C3", mobile:"9508973026", officer:"SF0059413", demand:2780, pending:2780, odRemarks:"", status:"Pending" },
  { id:"358307295", custId:"CID119105989", name:"MUNIYA DEVI", village:"Sevta", center:"504488", mobile:"9661334524", officer:"SF0061105", demand:3300, pending:3300, odRemarks:"", status:"Pending" },
  { id:"358836858", custId:"SSF4856525", name:"LAXMI DEVI", village:"Gola", center:"Gola C1", mobile:"8541963769", officer:"SF0053924", demand:1650, pending:1650, odRemarks:"", status:"Pending" },
  { id:"358836948", custId:"SID2125719658", name:"SARITA DEVI", village:"Bongabar", center:"159", mobile:"8521358109", officer:"SF0053924", demand:2950, pending:2950, odRemarks:"", status:"Pending" },
  { id:"358836963", custId:"CID119107065", name:"MALTI DEVI", village:"Pochra", center:"26", mobile:"8002456770", officer:"SF0059413", demand:1530, pending:1530, odRemarks:"", status:"Pending" },
  { id:"358924187", custId:"SSF2450133", name:"SUGANTI DEVI", village:"Sevta", center:"237", mobile:"9060338747", officer:"SF0061105", demand:2010, pending:2001, odRemarks:"FINANCIAL PROBLEM", status:"Pending" },
];

const EMPLOYEES = [
  { id:"SF0083835", name:"Rohit Kumar Gupta", role:"manager", short:"RKG" },
  { id:"SF0053924", name:"Vinay Kumar Mahto", role:"officer", short:"VKM" },
  { id:"SF0059413", name:"Dipak Kumar Paswan", role:"officer", short:"DKP" },
  { id:"SF0061105", name:"Ravi Paswan", role:"officer", short:"RP" },
];
const OFFICERS = EMPLOYEES.filter(e => e.role === "officer");
const BRANCH_TARGET = 500000;
const PENDING_TOTAL = { SF0053924:21093, SF0059413:22832, SF0061105:19419 };

const fmt = n => "₹" + Number(n||0).toLocaleString("en-IN",{minimumFractionDigits:0,maximumFractionDigits:0});
const todayStr = () => new Date().toISOString().split("T")[0];
const empName = id => EMPLOYEES.find(e=>e.id===id)?.name||id;
const empShort = id => EMPLOYEES.find(e=>e.id===id)?.short||id;

// localStorage helpers
const ld = (k, fb) => { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : fb; } catch { return fb; } };
const sv = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch {} };

const SC = {
  card: { background:"rgba(255,255,255,0.04)", border:"1px solid rgba(255,255,255,0.09)", borderRadius:16, padding:"16px 18px", marginBottom:12 },
  inp: { width:"100%", padding:"11px 14px", borderRadius:10, border:"1px solid rgba(255,255,255,0.15)", background:"rgba(255,255,255,0.07)", color:"#fff", fontSize:13, outline:"none", boxSizing:"border-box" },
  lbl: { color:"rgba(255,255,255,0.5)", fontSize:10, fontWeight:700, letterSpacing:0.8, display:"block", marginBottom:6, textTransform:"uppercase" },
  h2: { color:"#fff", fontSize:17, fontWeight:800, marginBottom:16 },
  btn: (bg="#10B981") => ({ padding:"8px 16px", borderRadius:9, border:"none", background:bg, color:"#fff", fontSize:12, fontWeight:700, cursor:"pointer" }),
};

function KPICard({ icon, label, value, sub, accent="#10B981" }) {
  return (
    <div style={{ background:"rgba(255,255,255,0.03)", border:"1px solid rgba(255,255,255,0.08)", borderRadius:16, padding:"16px 14px", position:"relative", overflow:"hidden" }}>
      <div style={{ position:"absolute", top:-14, right:-14, width:60, height:60, borderRadius:"50%", background:accent, opacity:0.1 }} />
      <div style={{ fontSize:20, marginBottom:6 }}>{icon}</div>
      <div style={{ color:"rgba(255,255,255,0.4)", fontSize:9, fontWeight:700, letterSpacing:1 }}>{label}</div>
      <div style={{ color:"#fff", fontSize:20, fontWeight:900, lineHeight:1.2, marginTop:2 }}>{value}</div>
      {sub && <div style={{ color:accent, fontSize:10, marginTop:4, fontWeight:600 }}>{sub}</div>}
    </div>
  );
}

function ProgressBar({ val, max, color="#10B981" }) {
  const pct = max>0 ? Math.min(100,Math.round((val/max)*100)) : 0;
  return (
    <div>
      <div style={{ height:8, background:"rgba(255,255,255,0.08)", borderRadius:8, overflow:"hidden" }}>
        <div style={{ height:"100%", width:pct+"%", background:`linear-gradient(90deg,#1E3A8A,${color})`, borderRadius:8, transition:"width 0.7s" }} />
      </div>
      <div style={{ display:"flex", justifyContent:"space-between", marginTop:3 }}>
        <span style={{ color, fontSize:10, fontWeight:700 }}>{pct}%</span>
        <span style={{ color:"rgba(255,255,255,0.3)", fontSize:10 }}>{fmt(val)} / {fmt(max)}</span>
      </div>
    </div>
  );
}

function Login({ onLogin }) {
  const [id, setId] = useState(""); const [pw, setPw] = useState(""); const [err, setErr] = useState(""); const [busy, setBusy] = useState(false);
  const go = () => {
    setBusy(true);
    setTimeout(() => {
      const emp = EMPLOYEES.find(e=>e.id===id&&id===pw);
      emp ? onLogin(emp) : (setErr("Invalid Employee ID or Password"), setBusy(false));
    }, 700);
  };
  return (
    <div style={{ minHeight:"100vh", background:"linear-gradient(135deg,#060d1a,#0d2137,#060d1a)", display:"flex", alignItems:"center", justifyContent:"center", fontFamily:"'Segoe UI',sans-serif" }}>
      <div style={{ background:"rgba(255,255,255,0.04)", backdropFilter:"blur(20px)", border:"1px solid rgba(255,255,255,0.1)", borderRadius:24, padding:"44px 36px", width:"min(320px, 90vw)", boxShadow:"0 32px 64px rgba(0,0,0,0.6)" }}>
        <div style={{ textAlign:"center", marginBottom:28 }}>
          <div style={{ width:56, height:56, borderRadius:14, background:"linear-gradient(135deg,#1E3A8A,#10B981)", display:"flex", alignItems:"center", justifyContent:"center", margin:"0 auto 12px", fontSize:24, boxShadow:"0 8px 24px rgba(16,185,129,0.25)" }}>🔍</div>
          <div style={{ color:"#fff", fontSize:19, fontWeight:800 }}>Ramgarh Digital Lens</div>
          <div style={{ color:"rgba(255,255,255,0.3)", fontSize:11, marginTop:3 }}>Spandana Sphoorty • JHGL1191</div>
        </div>
        {[["EMPLOYEE ID",id,setId,"SF0083835","text"],["PASSWORD",pw,setPw,"Enter password","password"]].map(([l,v,fn,ph,t])=>(
          <div key={l} style={{ marginBottom:14 }}>
            <label style={SC.lbl}>{l}</label>
            <input type={t} value={v} onChange={e=>{fn(e.target.value);setErr("");}} onKeyDown={e=>e.key==="Enter"&&go()} placeholder={ph} style={SC.inp} />
          </div>
        ))}
        {err && <div style={{ color:"#f87171", fontSize:12, marginBottom:8 }}>⚠ {err}</div>}
        <button onClick={go} disabled={busy} style={{ ...SC.btn(), width:"100%", padding:13, fontSize:14, marginTop:4, background:busy?"rgba(16,185,129,0.4)":"linear-gradient(135deg,#1E3A8A,#10B981)", borderRadius:12 }}>{busy?"Verifying...":"Login →"}</button>
        <div style={{ color:"rgba(255,255,255,0.2)", fontSize:10, textAlign:"center", marginTop:14 }}>Default Password = Employee ID</div>
      </div>
    </div>
  );
}

export default function App() {
  const [user, setUser] = useState(() => { try { const u = localStorage.getItem("rdl-user"); return u ? JSON.parse(u) : null; } catch { return null; } });
  const [tab, setTab] = useState("dashboard");
  const [customers, setCustomers] = useState(() => ld("rdl-cu", REAL_CUSTOMERS));
  const [proj, setProj] = useState(() => ld("rdl-pr", {}));
  const [ach, setAch] = useState(() => ld("rdl-ac", {}));
  const [callLog, setCallLog] = useState(() => ld("rdl-cl", {}));
  const [leads, setLeads] = useState(() => ld("rdl-le", []));
  const [plans, setPlans] = useState(() => ld("rdl-pl", {}));
  const [tasks, setTasks] = useState(() => ld("rdl-ta", []));
  const [extra, setExtra] = useState(() => ld("rdl-ex", {}));
  const [installPrompt, setInstallPrompt] = useState(null);
  const [showInstallBanner, setShowInstallBanner] = useState(false);

  // Capture install prompt
  useEffect(() => {
    const handler = e => { e.preventDefault(); setInstallPrompt(e); setShowInstallBanner(true); };
    window.addEventListener('beforeinstallprompt', handler);
    return () => window.removeEventListener('beforeinstallprompt', handler);
  }, []);

  const handleInstall = () => {
    if (installPrompt) { installPrompt.prompt(); installPrompt.userChoice.then(() => { setInstallPrompt(null); setShowInstallBanner(false); }); }
  };

  const login = u => { sv("rdl-user", u); setUser(u); setTab("dashboard"); };
  const logout = () => { localStorage.removeItem("rdl-user"); setUser(null); };

  if (!user) return <Login onLogin={login} />;

  const isM = user.role==="manager";
  const tday = todayStr();
  const todayAchs = Object.values(ach).filter(a=>a.date===tday);
  const collected = customers.filter(c=>c.status==="Collected").reduce((s,c)=>s+c.pending,0) + Object.values(extra).reduce((s,v)=>s+(v||0),0);
  const pendingCt = customers.filter(c=>c.status==="Pending").length;
  const totalCalls = Object.values(callLog).reduce((s,o)=>s+((o[tday])||0),0);
  const totalKYC = todayAchs.reduce((s,a)=>s+Number(a.kycDone||0),0);
  const myCu = isM ? customers : customers.filter(c=>c.officer===user.id);

  const villages = {};
  customers.forEach(c=>{
    if (!villages[c.village]) villages[c.village]={total:0,pending:0,amount:0};
    villages[c.village].total++;
    if (c.status==="Pending"){villages[c.village].pending++;villages[c.village].amount+=c.pending;}
  });

  const leaderboard = OFFICERS.map(o=>{
    const col=customers.filter(c=>c.officer===o.id&&c.status==="Collected").reduce((s,c)=>s+c.pending,0)+(extra[o.id]||0);
    return { ...o, collected:col, calls:(callLog[o.id]||{})[tday]||0, kyc:todayAchs.filter(a=>a.officerId===o.id).reduce((s,a)=>s+Number(a.kycDone||0),0), pendCt:customers.filter(c=>c.officer===o.id&&c.status==="Pending").length };
  }).sort((a,b)=>b.collected-a.collected);

  const focusCu = [...customers].filter(c=>c.status==="Pending").sort((a,b)=>{
    if(b.odRemarks&&!a.odRemarks)return 1; if(a.odRemarks&&!b.odRemarks)return -1; return b.pending-a.pending;
  }).slice(0,5);

  const markCollected = id => {
    const c=customers.find(x=>x.id===id); if(!c)return;
    const upCu=customers.map(x=>x.id===id?{...x,status:"Collected"}:x);
    const upEx={...extra,[c.officer]:(extra[c.officer]||0)+c.pending};
    setCustomers(upCu); setExtra(upEx); sv("rdl-cu",upCu); sv("rdl-ex",upEx);
  };

  const doCall = (officerId, mobile) => {
    window.location.href=`tel:${mobile}`;
    const up={...callLog,[officerId]:{...(callLog[officerId]||{}),[tday]:((callLog[officerId]||{})[tday]||0)+1}};
    setCallLog(up); sv("rdl-cl",up);
  };

  const manTabs=[{id:"dashboard",icon:"📊",label:"Dashboard"},{id:"emi",icon:"💰",label:"EMI"},{id:"radar",icon:"🗺",label:"Villages"},{id:"leaderboard",icon:"🏆",label:"Ranking"},{id:"focus",icon:"🎯",label:"Focus"},{id:"tasks",icon:"📋",label:"Tasks"},{id:"tomorrow",icon:"📅",label:"Tomorrow"},{id:"leads",icon:"➕",label:"Leads"},{id:"wa",icon:"💬",label:"WhatsApp"}];
  const offTabs=[{id:"dashboard",icon:"📊",label:"My Day"},{id:"projection",icon:"🌅",label:"Morning"},{id:"achievement",icon:"🌙",label:"Night"},{id:"emi",icon:"💰",label:"EMI"},{id:"tomorrow",icon:"📅",label:"Tomorrow"},{id:"leads",icon:"➕",label:"Leads"}];
  const tabs = isM ? manTabs : offTabs;

  const renderTab = () => {
    if (tab==="dashboard") {
      if (isM) return (
        <div>
          <div style={SC.h2}>🏦 Manager Super Dashboard</div>
          <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:10, marginBottom:14 }}>
            <KPICard icon="💰" label="Collected Today" value={fmt(collected)} sub={`of ${fmt(BRANCH_TARGET)} target`} accent="#10B981" />
            <KPICard icon="⏳" label="Pending EMIs" value={pendingCt} sub="customers" accent="#f59e0b" />
            <KPICard icon="📞" label="Calls Today" value={totalCalls} sub="all officers" accent="#ec4899" />
            <KPICard icon="✅" label="KYC Done" value={totalKYC} sub="today" accent="#6366f1" />
          </div>
          <div style={SC.card}>
            <div style={SC.lbl}>Branch Target Meter</div>
            <div style={{ color:"#fff", fontSize:18, fontWeight:900, marginBottom:8 }}>{fmt(collected)} <span style={{ color:"rgba(255,255,255,0.25)", fontSize:12, fontWeight:400 }}>/ {fmt(BRANCH_TARGET)}</span></div>
            <ProgressBar val={collected} max={BRANCH_TARGET} />
          </div>
          <div style={SC.card}>
            <div style={SC.lbl}>Officer Pending Amount</div>
            {OFFICERS.map(o=>{
              const pAmt=customers.filter(c=>c.officer===o.id&&c.status==="Pending").reduce((s,c)=>s+c.pending,0);
              return (<div key={o.id} style={{ marginBottom:14 }}>
                <div style={{ display:"flex", justifyContent:"space-between", marginBottom:4 }}>
                  <span style={{ color:"#fff", fontSize:13 }}>{o.name}</span>
                  <span style={{ color:"#ef4444", fontWeight:800, fontSize:13 }}>{fmt(pAmt)}</span>
                </div>
                <ProgressBar val={pAmt} max={PENDING_TOTAL[o.id]||1} color="#ef4444" />
              </div>);
            })}
          </div>
          <div style={SC.card}>
            <div style={SC.lbl}>Call Activity Today</div>
            {OFFICERS.map(o=>(
              <div key={o.id} style={{ display:"flex", justifyContent:"space-between", alignItems:"center", padding:"9px 0", borderBottom:"1px solid rgba(255,255,255,0.06)" }}>
                <span style={{ color:"#fff", fontSize:13 }}>{o.name}</span>
                <div style={{ display:"flex", gap:14 }}>
                  <span style={{ color:"#ec4899", fontWeight:700 }}>📞 {(callLog[o.id]||{})[tday]||0}</span>
                  <span style={{ color:"#10B981", fontWeight:700 }}>{fmt(customers.filter(c=>c.officer===o.id&&c.status==="Collected").reduce((s,c)=>s+c.pending,0)+(extra[o.id]||0))}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      );
      const myAch=todayAchs.find(a=>a.officerId===user.id)||{};
      const myProj=(proj[user.id]||{})[tday]||{};
      const myCol=customers.filter(c=>c.officer===user.id&&c.status==="Collected").reduce((s,c)=>s+c.pending,0)+(extra[user.id]||0);
      const myPendAmt=customers.filter(c=>c.officer===user.id&&c.status==="Pending").reduce((s,c)=>s+c.pending,0);
      return (
        <div>
          <div style={SC.h2}>👋 {user.name.split(" ")[0]} का Dashboard</div>
          <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:10, marginBottom:14 }}>
            <KPICard icon="💰" label="Collected" value={fmt(myCol)} accent="#10B981" />
            <KPICard icon="⏳" label="Pending" value={fmt(myPendAmt)} accent="#ef4444" />
            <KPICard icon="📞" label="Calls" value={(callLog[user.id]||{})[tday]||0} accent="#ec4899" />
            <KPICard icon="✅" label="KYC Done" value={myAch.kycDone||0} accent="#6366f1" />
          </div>
          {myProj.stdTarget && <div style={SC.card}><div style={SC.lbl}>Collection Target Progress</div><ProgressBar val={myCol} max={Number(myProj.stdTarget)} /></div>}
          <div style={SC.card}>
            <div style={SC.lbl}>मेरे Pending Customers</div>
            {customers.filter(c=>c.officer===user.id&&c.status==="Pending").map(c=>(
              <div key={c.id} style={{ display:"flex", justifyContent:"space-between", padding:"8px 0", borderBottom:"1px solid rgba(255,255,255,0.06)" }}>
                <span style={{ color:"#fff", fontSize:13 }}>{c.name} <span style={{ color:"rgba(255,255,255,0.35)", fontSize:11 }}>• {c.village}</span></span>
                <span style={{ color:"#f59e0b", fontWeight:700 }}>{fmt(c.pending)}</span>
              </div>
            ))}
          </div>
        </div>
      );
    }

    if (tab==="projection") {
      const exist=(proj[user.id]||{})[tday]||{};
      const [fm,setFm]=useState({kycTarget:exist.kycTarget||"",stdTarget:exist.stdTarget||"",nidhiTarget:exist.nidhiTarget||"",lucTarget:exist.lucTarget||"",mobileTarget:exist.mobileTarget||""});
      const saveP=()=>{const up={...proj,[user.id]:{...(proj[user.id]||{}),[tday]:{...fm,date:tday,officerId:user.id}}};setProj(up);sv("rdl-pr",up);alert("✅ Morning Projection save हो गया!");};
      return (<div><div style={SC.h2}>🌅 Morning Projection</div><div style={SC.card}>
        {[["kycTarget","KYC Target"],["stdTarget","STD Collection Target (₹)"],["nidhiTarget","Nidhi Target (₹)"],["lucTarget","LUC Target (₹)"],["mobileTarget","Mobile Update Target"]].map(([k,l])=>(
          <div key={k} style={{ marginBottom:14 }}><label style={SC.lbl}>{l}</label><input type="number" value={fm[k]} onChange={e=>setFm({...fm,[k]:e.target.value})} style={SC.inp} placeholder="0" /></div>
        ))}
        <button onClick={saveP} style={{ ...SC.btn(), width:"100%", padding:13 }}>💾 Save Morning Projection</button>
      </div></div>);
    }

    if (tab==="achievement") {
      const exist=todayAchs.find(a=>a.officerId===user.id)||{};
      const [fm,setFm]=useState({stdCollection:exist.stdCollection||"",kycDone:exist.kycDone||"",mobileUpdates:exist.mobileUpdates||"",remarks:exist.remarks||""});
      const saveA=()=>{const k=`${user.id}_${tday}`;const up={...ach,[k]:{...fm,date:tday,officerId:user.id}};setAch(up);sv("rdl-ac",up);alert("✅ Night Report submit हो गया!");};
      return (<div><div style={SC.h2}>🌙 Night Achievement Report</div><div style={SC.card}>
        {[["stdCollection","Actual STD Collection (₹)"],["kycDone","KYC Completed"],["mobileUpdates","Mobile Updates Done"]].map(([k,l])=>(
          <div key={k} style={{ marginBottom:14 }}><label style={SC.lbl}>{l}</label><input type="number" value={fm[k]} onChange={e=>setFm({...fm,[k]:e.target.value})} style={SC.inp} /></div>
        ))}
        <div style={{ marginBottom:14 }}><label style={SC.lbl}>Remarks</label><textarea value={fm.remarks} onChange={e=>setFm({...fm,remarks:e.target.value})} rows={3} style={{ ...SC.inp, resize:"vertical" }} placeholder="कोई issue हो तो लिखें..." /></div>
        <button onClick={saveA} style={{ ...SC.btn(), width:"100%", padding:13 }}>📤 Submit Night Report</button>
      </div></div>);
    }

    if (tab==="emi") {
      const pend=myCu.filter(c=>c.status==="Pending");
      const done=myCu.filter(c=>c.status==="Collected");
      return (<div>
        <div style={SC.h2}>💰 Pending EMI List <span style={{ background:"rgba(239,68,68,0.2)", color:"#ef4444", borderRadius:20, padding:"2px 10px", fontSize:12 }}>{pend.length}</span></div>
        {pend.map(c=>(
          <div key={c.id} style={{ ...SC.card, borderLeft:`3px solid ${c.odRemarks?"#ef4444":"#f59e0b"}` }}>
            <div style={{ display:"flex", justifyContent:"space-between", marginBottom:8 }}>
              <div style={{ flex:1 }}>
                <div style={{ color:"#fff", fontWeight:700, fontSize:14 }}>{c.name}</div>
                <div style={{ color:"rgba(255,255,255,0.35)", fontSize:11 }}>{c.village} • Center: {c.center}</div>
                <div style={{ color:"rgba(255,255,255,0.25)", fontSize:11 }}>Loan: {c.id} • {empShort(c.officer)}</div>
                {c.odRemarks&&<div style={{ color:"#ef4444", fontSize:11, fontWeight:700, marginTop:3 }}>⚠ {c.odRemarks}</div>}
              </div>
              <div style={{ textAlign:"right" }}>
                <div style={{ color:"#f59e0b", fontWeight:900, fontSize:17 }}>{fmt(c.pending)}</div>
                <div style={{ color:"rgba(255,255,255,0.25)", fontSize:10 }}>Demand: {fmt(c.demand)}</div>
              </div>
            </div>
            <div style={{ display:"flex", gap:8, flexWrap:"wrap" }}>
              <button onClick={()=>doCall(c.officer,c.mobile)} style={SC.btn("#1E3A8A")}>📞 {c.mobile}</button>
              <button onClick={()=>markCollected(c.id)} style={SC.btn("#10B981")}>✔ Mark Collected</button>
            </div>
          </div>
        ))}
        {done.length>0&&<><div style={{ color:"rgba(255,255,255,0.25)", fontSize:10, fontWeight:700, letterSpacing:1, marginTop:20, marginBottom:10 }}>✅ COLLECTED ({done.length})</div>
        {done.map(c=>(<div key={c.id} style={{ ...SC.card, opacity:0.5, borderLeft:"3px solid #10B981" }}><div style={{ display:"flex", justifyContent:"space-between" }}><div><div style={{ color:"#10B981", fontWeight:700 }}>{c.name}</div><div style={{ color:"rgba(255,255,255,0.3)", fontSize:11 }}>{c.village}</div></div><div style={{ color:"#10B981", fontWeight:800 }}>{fmt(c.pending)}</div></div></div>))}</>}
      </div>);
    }

    if (tab==="radar") {
      const sorted=Object.entries(villages).sort((a,b)=>b[1].amount-a[1].amount);
      return (<div>
        <div style={SC.h2}>🗺 Village Collection Radar</div>
        <div style={{ ...SC.card, background:"rgba(239,68,68,0.07)" }}>
          <div style={{ display:"flex", justifyContent:"space-between" }}>
            <span style={{ color:"rgba(255,255,255,0.5)", fontSize:13 }}>Total Pending</span>
            <span style={{ color:"#ef4444", fontWeight:900, fontSize:18 }}>{fmt(sorted.reduce((s,[,v])=>s+v.amount,0))}</span>
          </div>
        </div>
        {sorted.map(([v,s])=>{
          const pct=s.total>0?(s.pending/s.total)*100:0;
          const col=pct===100?"#ef4444":pct>=50?"#f59e0b":"#10B981";
          return (<div key={v} style={{ ...SC.card, borderLeft:`3px solid ${col}` }}>
            <div style={{ display:"flex", justifyContent:"space-between", marginBottom:8 }}>
              <div><div style={{ color:"#fff", fontWeight:700 }}>{v}</div><div style={{ color:"rgba(255,255,255,0.3)", fontSize:11 }}>{s.pending}/{s.total} pending</div></div>
              <div style={{ color:"#f59e0b", fontWeight:800, fontSize:15 }}>{fmt(s.amount)}</div>
            </div>
            <ProgressBar val={s.total-s.pending} max={s.total} color={col} />
          </div>);
        })}
      </div>);
    }

    if (tab==="leaderboard") {
      const medals=["🥇","🥈","🥉"];
      return (<div>
        <div style={SC.h2}>🏆 Team Performance Ranking</div>
        {leaderboard.map((o,i)=>(<div key={o.id} style={{ ...SC.card, background:i===0?"rgba(245,158,11,0.07)":"rgba(255,255,255,0.04)", borderLeft:`3px solid ${i===0?"#f59e0b":i===1?"#94a3b8":"#cd7c3a"}` }}>
          <div style={{ display:"flex", alignItems:"center", gap:12, marginBottom:10 }}>
            <div style={{ fontSize:26 }}>{medals[i]}</div>
            <div><div style={{ color:"#fff", fontWeight:800, fontSize:14 }}>{o.name}</div><div style={{ color:"rgba(255,255,255,0.35)", fontSize:11 }}>Pending: {o.pendCt} customers</div></div>
          </div>
          <div style={{ display:"grid", gridTemplateColumns:"repeat(3,1fr)", gap:8 }}>
            {[["💰",fmt(o.collected),"#10B981","Collected"],["📞",o.calls,"#ec4899","Calls"],["✅",o.kyc,"#6366f1","KYC"]].map(([ic,v,c,l])=>(
              <div key={l} style={{ background:"rgba(255,255,255,0.05)", borderRadius:10, padding:"8px", textAlign:"center" }}>
                <div style={{ color:c, fontSize:14, fontWeight:900 }}>{ic} {v}</div>
                <div style={{ color:"rgba(255,255,255,0.35)", fontSize:10, marginTop:2 }}>{l}</div>
              </div>
            ))}
          </div>
        </div>))}
      </div>);
    }

    if (tab==="focus") {
      return (<div>
        <div style={SC.h2}>🎯 Smart Focus Customers</div>
        {focusCu.map((c,i)=>(<div key={c.id} style={{ ...SC.card, borderLeft:"3px solid #ef4444" }}>
          <div style={{ display:"flex", justifyContent:"space-between", marginBottom:10 }}>
            <div>
              <div style={{ color:"rgba(255,255,255,0.3)", fontSize:10 }}>#{i+1} PRIORITY</div>
              <div style={{ color:"#fff", fontWeight:800, fontSize:15 }}>{c.name}</div>
              <div style={{ color:"rgba(255,255,255,0.35)", fontSize:12 }}>{c.village} • {empName(c.officer).split(" ")[0]}</div>
              {c.odRemarks&&<div style={{ color:"#ef4444", fontSize:11, fontWeight:700, marginTop:3 }}>⚠ {c.odRemarks}</div>}
            </div>
            <div style={{ color:"#f59e0b", fontWeight:900, fontSize:17 }}>{fmt(c.pending)}</div>
          </div>
          <div style={{ display:"flex", gap:8 }}>
            <button onClick={()=>doCall(c.officer,c.mobile)} style={SC.btn("#1E3A8A")}>📞 {c.mobile}</button>
            <button onClick={()=>markCollected(c.id)} style={SC.btn("#10B981")}>✔ Collected</button>
          </div>
        </div>))}
      </div>);
    }

    if (tab==="tasks") {
      const [nt,setNt]=useState({officer:"",desc:""});
      const addT=()=>{if(!nt.desc||!nt.officer)return;const up=[...tasks,{...nt,id:Date.now(),done:false,date:tday}];setTasks(up);sv("rdl-ta",up);setNt({officer:"",desc:""});};
      const tog=id=>{const up=tasks.map(t=>t.id===id?{...t,done:!t.done}:t);setTasks(up);sv("rdl-ta",up);};
      return (<div>
        <div style={SC.h2}>📋 Task Assignment</div>
        <div style={SC.card}>
          <div style={{ marginBottom:10 }}><label style={SC.lbl}>Assign To</label>
            <select value={nt.officer} onChange={e=>setNt({...nt,officer:e.target.value})} style={SC.inp}><option value="">Select Officer</option>{OFFICERS.map(o=><option key={o.id} value={o.id}>{o.name}</option>)}</select></div>
          <div style={{ marginBottom:12 }}><label style={SC.lbl}>Task</label><input value={nt.desc} onChange={e=>setNt({...nt,desc:e.target.value})} style={SC.inp} placeholder="Task description likhein" /></div>
          <button onClick={addT} style={{ ...SC.btn(), width:"100%", padding:12 }}>➕ Assign Task</button>
        </div>
        {tasks.map(t=>(<div key={t.id} style={{ ...SC.card, opacity:t.done?0.5:1 }}>
          <div style={{ display:"flex", gap:12, alignItems:"flex-start" }}>
            <input type="checkbox" checked={t.done} onChange={()=>tog(t.id)} style={{ marginTop:3, accentColor:"#10B981", width:16, height:16 }} />
            <div><div style={{ color:"#fff", textDecoration:t.done?"line-through":"none", fontSize:14 }}>{t.desc}</div><div style={{ color:"rgba(255,255,255,0.3)", fontSize:11, marginTop:4 }}>→ {empName(t.officer)} • {t.date}</div></div>
          </div>
        </div>))}
        {tasks.length===0&&<div style={{ color:"rgba(255,255,255,0.2)", textAlign:"center", padding:40 }}>कोई task नहीं है</div>}
      </div>);
    }

    if (tab==="tomorrow") {
      const tmrw=new Date(Date.now()+86400000).toISOString().split("T")[0];
      const myPlan=(plans[user.id]||{})[tmrw]||[];
      const [entries,setEntries]=useState(myPlan);
      const [fm,setFm]=useState({customer:"",village:"",target:""});
      const add=()=>{if(!fm.customer)return;const up=[...entries,{...fm,id:Date.now()}];setEntries(up);const obj={...plans,[user.id]:{...(plans[user.id]||{}),[tmrw]:up}};setPlans(obj);sv("rdl-pl",obj);setFm({customer:"",village:"",target:""}); };
      return (<div>
        <div style={SC.h2}>📅 Tomorrow's Plan</div>
        <div style={{ color:"rgba(255,255,255,0.35)", fontSize:12, marginBottom:14 }}>{new Date(tmrw).toLocaleDateString("en-IN",{weekday:"long",day:"numeric",month:"long"})}</div>
        <div style={SC.card}>
          {[["customer","Customer Name"],["village","Village"],["target","Target (₹)"]].map(([k,l])=>(
            <div key={k} style={{ marginBottom:12 }}><label style={SC.lbl}>{l}</label><input value={fm[k]} onChange={e=>setFm({...fm,[k]:e.target.value})} style={SC.inp} /></div>
          ))}
          <button onClick={add} style={{ ...SC.btn(), width:"100%", padding:12 }}>➕ Add to Plan</button>
        </div>
        {entries.map((e,i)=>(<div key={e.id} style={SC.card}><div style={{ color:"rgba(255,255,255,0.3)", fontSize:10 }}>#{i+1}</div><div style={{ color:"#fff", fontWeight:700 }}>{e.customer}</div><div style={{ color:"rgba(255,255,255,0.35)", fontSize:12 }}>{e.village}</div>{e.target&&<div style={{ color:"#10B981", fontWeight:700 }}>{fmt(e.target)}</div>}</div>))}
      </div>);
    }

    if (tab==="leads") {
      const [fm,setFm]=useState({name:"",village:"",mobile:"",remarks:""});
      const add=()=>{if(!fm.name)return;const up=[...leads,{...fm,id:Date.now(),officer:user.id,date:tday}];setLeads(up);sv("rdl-le",up);setFm({name:"",village:"",mobile:"",remarks:""});alert("✅ Lead save हो गया!");};
      const myL=isM?leads:leads.filter(l=>l.officer===user.id);
      return (<div>
        <div style={SC.h2}>➕ New Lead Capture</div>
        <div style={SC.card}>
          {[["name","Customer Name"],["village","Village"],["mobile","Mobile"],["remarks","Remarks"]].map(([k,l])=>(
            <div key={k} style={{ marginBottom:12 }}><label style={SC.lbl}>{l}</label><input value={fm[k]} onChange={e=>setFm({...fm,[k]:e.target.value})} style={SC.inp} /></div>
          ))}
          <button onClick={add} style={{ ...SC.btn(), width:"100%", padding:12 }}>💾 Save Lead</button>
        </div>
        {myL.map(l=>(<div key={l.id} style={SC.card}><div style={{ color:"#fff", fontWeight:700 }}>{l.name}</div><div style={{ color:"rgba(255,255,255,0.35)", fontSize:12 }}>{l.village} • {l.mobile}</div>{l.remarks&&<div style={{ color:"rgba(255,255,255,0.25)", fontSize:12 }}>{l.remarks}</div>}<div style={{ color:"rgba(255,255,255,0.2)", fontSize:10, marginTop:4 }}>{empShort(l.officer)} • {l.date}</div></div>))}
      </div>);
    }

    if (tab==="wa") {
      const dt=new Date().toLocaleDateString("en-IN",{day:"numeric",month:"long",year:"numeric"});
      const branchReport=()=>{
        let m=`🏦 *RAMGARH BRANCH DAILY REPORT*\n📅 ${dt}\n🏷 Branch: JHGL1191\n${"━".repeat(22)}\n\n`;
        m+=`💰 *COLLECTION*\nCollected: ${fmt(collected)}\nTarget: ${fmt(BRANCH_TARGET)}\nAchievement: ${Math.round((collected/BRANCH_TARGET)*100)}%\n\n`;
        m+=`📊 *OFFICER WISE*\n`;
        OFFICERS.forEach(o=>{
          const col=customers.filter(c=>c.officer===o.id&&c.status==="Collected").reduce((s,c)=>s+c.pending,0)+(extra[o.id]||0);
          const pend=customers.filter(c=>c.officer===o.id&&c.status==="Pending").length;
          m+=`👤 ${o.name}\n   💰 ${fmt(col)} | ⏳ ${pend} pending | 📞 ${(callLog[o.id]||{})[tday]||0} calls\n`;
        });
        m+=`\n⏳ Total Pending: ${pendingCt} customers\n📞 Total Calls: ${totalCalls}\n${"━".repeat(22)}\n_${user.name} | Ramgarh Digital Lens 🔍_`;
        return m;
      };
      const officerReport=(o)=>{
        const col=customers.filter(c=>c.officer===o.id&&c.status==="Collected").reduce((s,c)=>s+c.pending,0)+(extra[o.id]||0);
        const pend=customers.filter(c=>c.officer===o.id&&c.status==="Pending");
        const a=todayAchs.find(x=>x.officerId===o.id)||{};
        const p=(proj[o.id]||{})[tday]||{};
        let m=`📋 *DAILY REPORT*\n👤 ${o.name}\n📅 ${dt}\n${"━".repeat(20)}\n\n`;
        m+=`💰 STD Collection\n   Target: ${fmt(p.stdTarget||0)} | Achieved: ${fmt(col)}\n\n`;
        m+=`✅ KYC: ${a.kycDone||0} | 📞 Calls: ${(callLog[o.id]||{})[tday]||0} | 📱 Mobile: ${a.mobileUpdates||0}\n\n`;
        m+=`⏳ *Pending (${pend.length})*:\n`;
        pend.forEach(c=>{m+=`• ${c.name} | ${c.village} | ${fmt(c.pending)}${c.odRemarks?" ⚠":""}\n`;});
        if(a.remarks)m+=`\n📝 ${a.remarks}\n`;
        m+=`${"━".repeat(20)}\n_Ramgarh Digital Lens 🔍_`;
        return m;
      };
      const copy=txt=>navigator.clipboard.writeText(txt).then(()=>alert("✅ Copied! WhatsApp पर paste करें।"));
      return (<div>
        <div style={SC.h2}>💬 WhatsApp Report Generator</div>
        <div style={SC.card}>
          <div style={SC.lbl}>🏦 Branch Summary Report</div>
          <div style={{ background:"rgba(0,0,0,0.4)", borderRadius:10, padding:12, fontSize:11, color:"rgba(255,255,255,0.6)", whiteSpace:"pre-wrap", fontFamily:"monospace", maxHeight:180, overflowY:"auto", marginBottom:10 }}>{branchReport()}</div>
          <button onClick={()=>copy(branchReport())} style={{ ...SC.btn("#25D366"), width:"100%", padding:11 }}>📋 Copy Branch Report</button>
        </div>
        {OFFICERS.map(o=>(<div key={o.id} style={SC.card}>
          <div style={SC.lbl}>👤 {o.name}</div>
          <div style={{ background:"rgba(0,0,0,0.4)", borderRadius:10, padding:12, fontSize:11, color:"rgba(255,255,255,0.6)", whiteSpace:"pre-wrap", fontFamily:"monospace", maxHeight:160, overflowY:"auto", marginBottom:10 }}>{officerReport(o)}</div>
          <button onClick={()=>copy(officerReport(o))} style={{ ...SC.btn("#25D366"), width:"100%", padding:11 }}>📋 Copy {o.short}'s Report</button>
        </div>))}
      </div>);
    }
    return null;
  };

  return (
    <div style={{ minHeight:"100vh", background:"#060d1a", fontFamily:"'Segoe UI',sans-serif", color:"#fff" }}>
      {/* Install Banner */}
      {showInstallBanner && (
        <div style={{ background:"linear-gradient(135deg,#1E3A8A,#10B981)", padding:"10px 16px", display:"flex", justifyContent:"space-between", alignItems:"center" }}>
          <span style={{ color:"#fff", fontSize:13, fontWeight:600 }}>📱 Install Ramgarh Digital Lens as App</span>
          <div style={{ display:"flex", gap:8 }}>
            <button onClick={handleInstall} style={{ background:"#fff", color:"#1E3A8A", border:"none", borderRadius:8, padding:"5px 14px", fontSize:12, fontWeight:800, cursor:"pointer" }}>Install</button>
            <button onClick={()=>setShowInstallBanner(false)} style={{ background:"rgba(255,255,255,0.2)", color:"#fff", border:"none", borderRadius:8, padding:"5px 10px", fontSize:12, cursor:"pointer" }}>✕</button>
          </div>
        </div>
      )}

      {/* Header */}
      <div style={{ background:"rgba(30,58,138,0.92)", backdropFilter:"blur(12px)", padding:"10px 14px", display:"flex", justifyContent:"space-between", alignItems:"center", position:"sticky", top:0, zIndex:100, borderBottom:"1px solid rgba(255,255,255,0.08)" }}>
        <div style={{ display:"flex", alignItems:"center", gap:9 }}>
          <div style={{ width:32, height:32, borderRadius:9, background:"linear-gradient(135deg,#1E3A8A,#10B981)", display:"flex", alignItems:"center", justifyContent:"center", fontSize:15 }}>🔍</div>
          <div><div style={{ color:"#fff", fontWeight:800, fontSize:13 }}>Ramgarh Digital Lens</div><div style={{ color:"rgba(255,255,255,0.3)", fontSize:9 }}>JHGL1191 • Spandana Sphoorty</div></div>
        </div>
        <div style={{ display:"flex", alignItems:"center", gap:8 }}>
          <div style={{ textAlign:"right" }}>
            <div style={{ color:"#fff", fontSize:11, fontWeight:700 }}>{user.short}</div>
            <div style={{ color:"#10B981", fontSize:9 }}>{isM?"Branch Manager":"Loan Officer"}</div>
          </div>
          <button onClick={logout} style={{ background:"rgba(239,68,68,0.15)", border:"1px solid rgba(239,68,68,0.25)", color:"#ef4444", borderRadius:8, padding:"4px 10px", fontSize:10, cursor:"pointer" }}>Exit</button>
        </div>
      </div>

      {/* Content */}
      <div style={{ padding:"14px 12px 90px" }}>{renderTab()}</div>

      {/* Bottom Nav */}
      <div style={{ position:"fixed", bottom:0, left:0, right:0, background:"rgba(4,9,20,0.97)", backdropFilter:"blur(20px)", borderTop:"1px solid rgba(255,255,255,0.07)", display:"flex", overflowX:"auto", padding:"6px 2px 8px" }}>
        {tabs.map(t=>(
          <button key={t.id} onClick={()=>setTab(t.id)} style={{ flex:"0 0 auto", minWidth:58, padding:"5px 4px", background:tab===t.id?"rgba(16,185,129,0.15)":"none", border:"none", cursor:"pointer", display:"flex", flexDirection:"column", alignItems:"center", gap:2, borderRadius:10 }}>
            <span style={{ fontSize:17 }}>{t.icon}</span>
            <span style={{ fontSize:9, fontWeight:700, color:tab===t.id?"#10B981":"rgba(255,255,255,0.3)" }}>{t.label}</span>
          </button>
        ))}
      </div>
    </div>
  );
}
